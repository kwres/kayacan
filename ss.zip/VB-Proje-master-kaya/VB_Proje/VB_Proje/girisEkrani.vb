﻿Public Class kullaniciGiris_ekrani
    Private Sub btn_giris_Click(sender As Object, e As EventArgs) Handles btn_giris.Click


        yoneticiAnasayfa.Show()



    End Sub
End Class
