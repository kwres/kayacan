# VB-Proje
3.Sınıf Görsel Programlama Dersi Dönem Projesi

Görsel içerikler hazırlanarak projenin ana taslağı oluşturuldu(7.10.2017)

Proje içinde eksik olan görseller içerikler eklendi. Proje için gerekli olan veritabanı tasarımı yapıldı.(15.10.2017)
